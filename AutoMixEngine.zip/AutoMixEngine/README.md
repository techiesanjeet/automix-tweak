# AutoMixEngine

Theos dylib: CoreAudio crossfade DSP + floating settings menu.

## Before pushing
Add these two files (from https://github.com/facebook/fishhook) next to AutoMixEngine.mm:
- fishhook.c
- fishhook.h

## Build
Push to GitHub -> Actions tab -> "Build dylib" -> download the AutoMixEngine-dylib artifact.
